import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MediaCard } from "./MediaCard";
import { UploadArea } from "./UploadArea";
import { ActivityHistory } from "./ActivityHistory";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Alert, AlertDescription } from "./ui/alert";
import { Heart, Sparkles, LogOut, Crown, Camera, Video, Cloud, Wifi, WifiOff, AlertCircle, CheckCircle } from "lucide-react";
import { useSupabase } from "../hooks/useSupabase";
import { showNotification } from "./NotificationToast";
import { Toaster } from "./ui/sonner";

export function SupabaseGallery() {
  const { 
    user, 
    profile, 
    medias, 
    activities, 
    loading,
    signOut,
    uploadMedia,
    deleteMedia,
    addReaction,
    clearActivities
  } = useSupabase();

  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [operationStatus, setOperationStatus] = useState<string | null>(null);

  // Monitor online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleFileSelect = async (files: FileList) => {
    if (!isOnline) {
      showNotification({
        type: 'upload',
        message: 'Tidak dapat upload saat offline. Mohon periksa koneksi internet.'
      });
      return;
    }

    const fileArray = Array.from(files);
    setOperationStatus('Mengupload file...');

    for (const file of fileArray) {
      const fileId = `${Date.now()}-${file.name}`;
      
      try {
        setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));
        
        // Simulate upload progress
        const progressInterval = setInterval(() => {
          setUploadProgress(prev => ({
            ...prev,
            [fileId]: Math.min((prev[fileId] || 0) + 10, 90)
          }));
        }, 200);

        const isVideo = file.type.startsWith('video/');
        await uploadMedia(file, file.name);
        
        clearInterval(progressInterval);
        setUploadProgress(prev => ({ ...prev, [fileId]: 100 }));
        
        showNotification({
          type: 'upload',
          message: `${isVideo ? 'Video' : 'Foto'} "${file.name}" berhasil diupload ke cloud`,
          mediaType: isVideo ? 'video' : 'photo'
        });

        // Clean up progress after a delay
        setTimeout(() => {
          setUploadProgress(prev => {
            const newProgress = { ...prev };
            delete newProgress[fileId];
            return newProgress;
          });
        }, 2000);
        
      } catch (error: any) {
        console.error('Upload error:', error);
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
        
        showNotification({
          type: 'upload',
          message: `Gagal mengupload "${file.name}": ${error.message}`
        });
      }
    }
    
    setOperationStatus(null);
  };

  const handleDeleteMedia = async (mediaId: string) => {
    if (!isOnline) {
      showNotification({
        type: 'delete',
        message: 'Tidak dapat menghapus saat offline. Mohon periksa koneksi internet.'
      });
      return;
    }

    const media = medias.find(m => m.id === mediaId);
    if (!media) return;

    try {
      setOperationStatus('Menghapus media...');
      await deleteMedia(mediaId);
      
      showNotification({
        type: 'delete',
        message: `${media.type === 'video' ? 'Video' : 'Foto'} "${media.alt}" telah dihapus dari cloud`,
        mediaType: media.type
      });
    } catch (error: any) {
      console.error('Delete error:', error);
      showNotification({
        type: 'delete',
        message: `Gagal menghapus media: ${error.message}`
      });
    } finally {
      setOperationStatus(null);
    }
  };

  const handleReaction = async (mediaId: string, emoji: string) => {
    if (!isOnline) {
      showNotification({
        type: 'reaction',
        message: 'Tidak dapat menambah reaksi saat offline.',
        emoji
      });
      return;
    }

    try {
      await addReaction(mediaId, emoji);
      
      showNotification({
        type: 'reaction',
        message: `Reaksi ${emoji} berhasil ditambahkan`,
        emoji
      });
    } catch (error: any) {
      console.error('Reaction error:', error);
      showNotification({
        type: 'reaction',
        message: `Gagal menambah reaksi: ${error.message}`
      });
    }
  };

  const handleLogout = async () => {
    try {
      setOperationStatus('Keluar dari akun...');
      await signOut();
      showNotification({
        type: 'upload',
        message: 'Berhasil keluar dari galeri pribadi'
      });
    } catch (error: any) {
      console.error('Logout error:', error);
      showNotification({
        type: 'upload',
        message: `Gagal keluar: ${error.message}`
      });
    } finally {
      setOperationStatus(null);
    }
  };

  const clearAllMedia = async () => {
    if (!isOnline) {
      showNotification({
        type: 'delete',
        message: 'Tidak dapat menghapus semua media saat offline.'
      });
      return;
    }

    if (medias.length === 0) return;

    try {
      setOperationStatus('Menghapus semua media...');
      
      for (const media of medias) {
        await deleteMedia(media.id);
      }
      
      showNotification({
        type: 'delete',
        message: `Semua ${medias.length} media telah dihapus dari cloud`
      });
    } catch (error: any) {
      console.error('Clear all error:', error);
      showNotification({
        type: 'delete',
        message: `Gagal menghapus semua media: ${error.message}`
      });
    } finally {
      setOperationStatus(null);
    }
  };

  const clearHistory = async () => {
    try {
      await clearActivities();
      showNotification({
        type: 'upload',
        message: 'Riwayat aktivitas telah dibersihkan'
      });
    } catch (error: any) {
      console.error('Clear history error:', error);
      showNotification({
        type: 'upload',
        message: `Gagal membersihkan riwayat: ${error.message}`
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full"
        />
        <span className="ml-3 text-muted-foreground">Memuat galeri...</span>
      </div>
    );
  }

  if (!user || !profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Mohon login terlebih dahulu</p>
      </div>
    );
  }

  const photoCount = medias.filter(m => m.type === 'photo').length;
  const videoCount = medias.filter(m => m.type === 'video').length;
  const totalReactions = medias.reduce((sum, media) => 
    sum + Object.values(media.reactions).reduce((a, b) => a + b, 0), 0
  );

  // Convert Supabase media to component format
  const convertedMedias = medias.map(media => ({
    id: media.id,
    src: media.url,
    alt: media.alt,
    type: media.type,
    reactions: media.reactions
  }));

  // Convert Supabase activities to component format
  const convertedActivities = activities.map(activity => ({
    id: activity.id,
    type: activity.type,
    message: activity.message,
    timestamp: new Date(activity.timestamp),
    mediaType: activity.mediaType,
    emoji: activity.emoji
  }));

  return (
    <div className="space-y-8">
      <Toaster position="top-right" />
      
      {/* Online/Offline Status */}
      {!isOnline && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Alert variant="destructive">
            <WifiOff className="h-4 w-4" />
            <AlertDescription>
              Anda sedang offline. Beberapa fitur mungkin tidak tersedia.
            </AlertDescription>
          </Alert>
        </motion.div>
      )}

      {/* Operation Status */}
      {operationStatus && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Alert className="border-primary/20 bg-primary/5">
            <Cloud className="h-4 w-4 text-primary animate-pulse" />
            <AlertDescription className="text-primary">
              {operationStatus}
            </AlertDescription>
          </Alert>
        </motion.div>
      )}

      {/* Upload Progress */}
      {Object.keys(uploadProgress).length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-2"
        >
          {Object.entries(uploadProgress).map(([fileId, progress]) => (
            <div key={fileId} className="bg-secondary/50 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">
                  Mengupload... {progress}%
                </span>
                {progress === 100 && <CheckCircle className="h-4 w-4 text-green-500" />}
              </div>
              <div className="w-full bg-background rounded-full h-2">
                <motion.div
                  className="bg-primary rounded-full h-2"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>
          ))}
        </motion.div>
      )}

      {/* Header with user info */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div className="flex items-center gap-4">
          <Avatar className="h-12 w-12 border-2 border-primary/20">
            <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white">
              {profile.displayName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-primary">{profile.displayName}</h2>
              <Crown className="h-4 w-4 text-primary" />
              {isOnline ? (
                <Wifi className="h-4 w-4 text-green-500" />
              ) : (
                <WifiOff className="h-4 w-4 text-destructive" />
              )}
            </div>
            <p className="text-muted-foreground text-sm">{user.email}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <ActivityHistory 
            activities={convertedActivities} 
            onClearHistory={clearHistory} 
          />
          <Button variant="outline" onClick={handleLogout} disabled={!isOnline}>
            <LogOut className="h-4 w-4 mr-2" />
            Keluar
          </Button>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center space-y-4"
      >
        <div className="flex items-center justify-center space-x-2">
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Heart className="h-8 w-8 text-primary fill-current" />
          </motion.div>
          <h1 className="text-primary">Album Pribadi Cloud</h1>
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Sparkles className="h-8 w-8 text-primary" />
          </motion.div>
        </div>
        
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
            <Camera className="h-3 w-3 mr-1" />
            {photoCount} Foto
          </Badge>
          <Badge variant="outline" className="bg-secondary/50 text-secondary-foreground border-secondary">
            <Video className="h-3 w-3 mr-1" />
            {videoCount} Video
          </Badge>
          <Badge variant="outline" className="bg-pink-50 text-pink-700 border-pink-200">
            <Heart className="h-3 w-3 mr-1" />
            {totalReactions} Reaksi
          </Badge>
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            <Cloud className="h-3 w-3 mr-1" />
            Cloud Storage
          </Badge>
        </div>
        
        <p className="text-muted-foreground max-w-md mx-auto">
          Galeri pribadi yang aman dengan backup cloud otomatis dan sinkronisasi real-time ☁️🌸
        </p>
      </motion.div>

      {/* Upload Area */}
      <UploadArea onFileSelect={handleFileSelect} />

      {/* Gallery Controls */}
      {medias.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center justify-between"
        >
          <p className="text-muted-foreground">
            {medias.length} item tersimpan di cloud
          </p>
          <Button 
            variant="outline" 
            onClick={clearAllMedia}
            disabled={!isOnline}
            className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
          >
            Hapus Semua
          </Button>
        </motion.div>
      )}

      {/* Media Grid - Masonry Layout */}
      {medias.length > 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="masonry-grid"
        >
          <AnimatePresence>
            {convertedMedias.map((media) => (
              <MediaCard
                key={media.id}
                id={media.id}
                src={media.src}
                alt={media.alt}
                type={media.type}
                reactions={media.reactions}
                onDelete={handleDeleteMedia}
                onReaction={handleReaction}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-16"
        >
          <motion.div
            className="rounded-full bg-secondary/50 w-24 h-24 mx-auto mb-6 flex items-center justify-center"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Cloud className="h-12 w-12 text-primary/50" />
          </motion.div>
          <h3 className="text-primary mb-2">Cloud Storage Kosong</h3>
          <p className="text-muted-foreground">
            Upload foto atau video pertama Anda untuk memulai koleksi galeri cloud yang aman ☁️✨
          </p>
        </motion.div>
      )}
    </div>
  );
}