import { useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner@2.0.3";
import { Heart, Trash2, Upload, Camera, Video } from "lucide-react";

export interface Notification {
  id: string;
  type: 'upload' | 'delete' | 'reaction';
  message: string;
  timestamp: Date;
  mediaType?: 'photo' | 'video';
  emoji?: string;
}

interface NotificationToastProps {
  notification: Notification;
}

export function NotificationToast({ notification }: NotificationToastProps) {
  const getIcon = () => {
    switch (notification.type) {
      case 'upload':
        if (notification.mediaType === 'video') {
          return <Video className="h-5 w-5 text-primary" />;
        }
        return <Camera className="h-5 w-5 text-primary" />;
      case 'delete':
        return <Trash2 className="h-5 w-5 text-destructive" />;
      case 'reaction':
        return <Heart className="h-5 w-5 text-pink-500 fill-current" />;
      default:
        return <Heart className="h-5 w-5 text-primary" />;
    }
  };

  const getEmoji = () => {
    switch (notification.type) {
      case 'upload':
        return notification.mediaType === 'video' ? '🎬' : '📸';
      case 'delete':
        return '🗑️';
      case 'reaction':
        return notification.emoji || '❤️';
      default:
        return '✨';
    }
  };

  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0, y: 20 }}
      animate={{ scale: 1, opacity: 1, y: 0 }}
      exit={{ scale: 0.8, opacity: 0, y: -20 }}
      className="flex items-center gap-3 p-4 bg-card border border-primary/20 rounded-lg shadow-lg"
    >
      <motion.div
        animate={{ rotate: [0, 10, -10, 0] }}
        transition={{ duration: 1, repeat: 2 }}
        className="flex-shrink-0"
      >
        {getIcon()}
      </motion.div>
      
      <div className="flex-1">
        <p className="text-card-foreground">{notification.message}</p>
        <p className="text-muted-foreground text-sm">
          {notification.timestamp.toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit'
          })}
        </p>
      </div>
      
      <motion.span
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ duration: 0.6, repeat: Infinity, delay: 0.5 }}
        className="text-xl"
      >
        {getEmoji()}
      </motion.span>
    </motion.div>
  );
}

export function showNotification(notification: Omit<Notification, 'id' | 'timestamp'>) {
  const fullNotification: Notification = {
    ...notification,
    id: Date.now().toString(),
    timestamp: new Date()
  };

  toast.custom((t) => (
    <NotificationToast notification={fullNotification} />
  ), {
    duration: 3000,
  });
}