import { useRef } from "react";
import { motion } from "motion/react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Upload, Plus, Camera, Video } from "lucide-react";

interface UploadAreaProps {
  onFileSelect: (files: FileList) => void;
}

export function UploadArea({ onFileSelect }: UploadAreaProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      onFileSelect(files);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      onFileSelect(files);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Card
        className="border-2 border-dashed border-primary/30 bg-secondary/50 hover:bg-secondary/70 hover:border-primary/50 transition-all duration-500 cursor-pointer p-8 relative overflow-hidden"
        onClick={handleClick}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        {/* Floating background elements */}
        <div className="absolute inset-0 pointer-events-none">
          <motion.div
            className="absolute top-4 left-4"
            animate={{ y: [0, -10, 0], rotate: [0, 5, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Camera className="h-6 w-6 text-primary/20" />
          </motion.div>
          <motion.div
            className="absolute top-6 right-6"
            animate={{ y: [0, -8, 0], rotate: [0, -5, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
          >
            <Video className="h-5 w-5 text-primary/20" />
          </motion.div>
          <motion.div
            className="absolute bottom-6 left-8"
            animate={{ y: [0, -6, 0], x: [0, 2, 0] }}
            transition={{ duration: 4, repeat: Infinity, delay: 1 }}
          >
            <Plus className="h-4 w-4 text-primary/15" />
          </motion.div>
        </div>

        <div className="flex flex-col items-center justify-center space-y-6 relative z-10">
          <motion.div
            className="rounded-full bg-gradient-to-br from-primary/20 to-secondary/30 p-6"
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Upload className="h-12 w-12 text-primary" />
            </motion.div>
          </motion.div>
          
          <div className="text-center space-y-3">
            <motion.h3
              className="text-primary"
              whileHover={{ scale: 1.05 }}
            >
              Upload Media Baru
            </motion.h3>
            <p className="text-muted-foreground max-w-sm">
              Drag & drop foto atau video di sini, atau klik untuk memilih dari perangkat Anda
            </p>
            <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Camera className="h-4 w-4" />
                <span>Foto</span>
              </div>
              <div className="w-1 h-1 bg-muted-foreground rounded-full"></div>
              <div className="flex items-center gap-1">
                <Video className="h-4 w-4" />
                <span>Video</span>
              </div>
            </div>
          </div>
          
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button 
              variant="outline" 
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300"
            >
              <Plus className="h-4 w-4 mr-2" />
              Pilih File
            </Button>
          </motion.div>
        </div>
        
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,video/*"
          multiple
          className="hidden"
          onChange={handleFileChange}
        />
      </Card>
    </motion.div>
  );
}