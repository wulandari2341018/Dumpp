import { useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogTrigger } from "./ui/dialog";
import { Trash2 } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface PhotoCardProps {
  id: string;
  src: string;
  alt: string;
  onDelete: (id: string) => void;
}

export function PhotoCard({ id, src, alt, onDelete }: PhotoCardProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(id);
  };

  return (
    <Card className="group relative overflow-hidden bg-card hover:shadow-lg transition-all duration-300 border-2 border-secondary">
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <div className="cursor-pointer">
            <div className="aspect-square overflow-hidden">
              <ImageWithFallback
                src={src}
                alt={alt}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
          </div>
        </DialogTrigger>
        <DialogContent className="max-w-4xl w-full p-0 bg-card">
          <div className="relative">
            <ImageWithFallback
              src={src}
              alt={alt}
              className="w-full h-auto max-h-[80vh] object-contain"
            />
          </div>
        </DialogContent>
      </Dialog>
      
      <Button
        variant="destructive"
        size="icon"
        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 h-8 w-8"
        onClick={handleDelete}
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </Card>
  );
}