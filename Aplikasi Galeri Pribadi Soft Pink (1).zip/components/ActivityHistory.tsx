import { motion } from "motion/react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";
import { Badge } from "./ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";
import { History, Camera, Video, Trash2, Heart, Clock } from "lucide-react";
import { Notification } from "./NotificationToast";

interface ActivityHistoryProps {
  activities: Notification[];
  onClearHistory: () => void;
}

export function ActivityHistory({ activities, onClearHistory }: ActivityHistoryProps) {
  const getActivityIcon = (type: string, mediaType?: string) => {
    switch (type) {
      case 'upload':
        return mediaType === 'video' ? (
          <Video className="h-4 w-4 text-primary" />
        ) : (
          <Camera className="h-4 w-4 text-primary" />
        );
      case 'delete':
        return <Trash2 className="h-4 w-4 text-destructive" />;
      case 'reaction':
        return <Heart className="h-4 w-4 text-pink-500" />;
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'upload':
        return 'bg-primary/10 text-primary border-primary/20';
      case 'delete':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'reaction':
        return 'bg-pink-100 text-pink-700 border-pink-200';
      default:
        return 'bg-muted text-muted-foreground border-border';
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 1) return 'Baru saja';
    if (minutes < 60) return `${minutes} menit lalu`;
    if (hours < 24) return `${hours} jam lalu`;
    return `${days} hari lalu`;
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="relative">
          <History className="h-4 w-4" />
          {activities.length > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-1 -right-1 bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs"
            >
              {activities.length > 99 ? '99+' : activities.length}
            </motion.div>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full sm:w-[400px]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            Riwayat Aktivitas
          </SheetTitle>
        </SheetHeader>
        
        <div className="mt-6 space-y-4">
          {activities.length > 0 && (
            <div className="flex justify-between items-center">
              <p className="text-muted-foreground">
                {activities.length} aktivitas
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={onClearHistory}
                className="text-destructive border-destructive/30 hover:bg-destructive hover:text-destructive-foreground"
              >
                Bersihkan
              </Button>
            </div>
          )}

          <ScrollArea className="h-[calc(100vh-200px)]">
            <div className="space-y-3">
              {activities.length === 0 ? (
                <div className="text-center py-12">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-16 h-16 mx-auto mb-4 bg-secondary/50 rounded-full flex items-center justify-center"
                  >
                    <History className="h-8 w-8 text-muted-foreground" />
                  </motion.div>
                  <h3 className="text-muted-foreground mb-2">Belum Ada Aktivitas</h3>
                  <p className="text-muted-foreground">
                    Mulai upload foto atau berikan reaksi untuk melihat riwayat
                  </p>
                </div>
              ) : (
                activities.map((activity, index) => (
                  <motion.div
                    key={activity.id}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="p-4 border border-border/50">
                      <div className="flex items-start gap-3">
                        <div className="mt-1">
                          {getActivityIcon(activity.type, activity.mediaType)}
                        </div>
                        <div className="flex-1 space-y-2">
                          <p className="text-sm">{activity.message}</p>
                          <div className="flex items-center gap-2">
                            <Badge
                              variant="outline"
                              className={`text-xs ${getActivityColor(activity.type)}`}
                            >
                              {activity.type === 'upload' ? 'Upload' : 
                               activity.type === 'delete' ? 'Hapus' : 'Reaksi'}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {formatTime(activity.timestamp)}
                            </span>
                          </div>
                          {activity.emoji && (
                            <motion.span
                              animate={{ scale: [1, 1.1, 1] }}
                              transition={{ duration: 1, repeat: Infinity }}
                              className="text-lg"
                            >
                              {activity.emoji}
                            </motion.span>
                          )}
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
}