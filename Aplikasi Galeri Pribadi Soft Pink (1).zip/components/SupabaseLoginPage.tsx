import { useState } from "react";
import { motion } from "motion/react";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Alert, AlertDescription } from "./ui/alert";
import { Heart, Sparkles, User, Crown, Mail, Lock, AlertCircle } from "lucide-react";
import { useSupabase } from "../hooks/useSupabase";

export function SupabaseLoginPage() {
  const { signIn, signUp, loading } = useSupabase();
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Sign in form
  const [signInData, setSignInData] = useState({
    email: "",
    password: ""
  });

  // Sign up form
  const [signUpData, setSignUpData] = useState({
    email: "",
    password: "",
    displayName: ""
  });

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    try {
      await signIn(signInData.email, signInData.password);
      setSuccess("Berhasil masuk ke galeri pribadi Anda!");
    } catch (err: any) {
      setError(err.message || "Gagal masuk. Periksa email dan password Anda.");
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (signUpData.password.length < 6) {
      setError("Password harus minimal 6 karakter");
      return;
    }

    try {
      await signUp(signUpData.email, signUpData.password, signUpData.displayName);
      setSuccess("Akun berhasil dibuat! Selamat datang di galeri pribadi Anda!");
    } catch (err: any) {
      setError(err.message || "Gagal membuat akun. Coba lagi nanti.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Floating background elements */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 5, -5, 0],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          >
            {i % 3 === 0 ? (
              <Heart className="h-4 w-4 text-primary/20 fill-current" />
            ) : i % 3 === 1 ? (
              <Sparkles className="h-4 w-4 text-secondary/30" />
            ) : (
              <Crown className="h-3 w-3 text-accent/40" />
            )}
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ scale: 0.8, opacity: 0, y: 50 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="w-full max-w-md relative z-10"
      >
        <Card className="p-8 backdrop-blur-sm bg-card/95 border-2 border-primary/20 shadow-2xl">
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="text-center mb-8"
          >
            <motion.div
              className="flex items-center justify-center space-x-3 mb-4"
              whileHover={{ scale: 1.05 }}
            >
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Heart className="h-12 w-12 text-primary fill-current" />
              </motion.div>
              <h1 className="text-primary">Album Pribadi</h1>
              <motion.div
                animate={{ rotate: [0, -10, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
              >
                <Sparkles className="h-12 w-12 text-primary" />
              </motion.div>
            </motion.div>
            <p className="text-muted-foreground">
              Galeri pribadi yang aman dengan sinkronisasi cloud ☁️✨
            </p>
          </motion.div>

          {/* Error/Success Messages */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4"
            >
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            </motion.div>
          )}

          {success && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4"
            >
              <Alert className="border-primary/20 bg-primary/5">
                <Heart className="h-4 w-4 text-primary" />
                <AlertDescription className="text-primary">{success}</AlertDescription>
              </Alert>
            </motion.div>
          )}

          <Tabs defaultValue="signin" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="signin">Masuk</TabsTrigger>
              <TabsTrigger value="signup">Daftar</TabsTrigger>
            </TabsList>

            <TabsContent value="signin" className="space-y-4">
              <motion.form
                onSubmit={handleSignIn}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Label htmlFor="signin-email" className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-primary" />
                    Email
                  </Label>
                  <Input
                    id="signin-email"
                    type="email"
                    placeholder="nama@email.com"
                    value={signInData.email}
                    onChange={(e) => setSignInData(prev => ({ ...prev, email: e.target.value }))}
                    className="border-primary/30 focus:border-primary bg-input-background"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signin-password" className="flex items-center gap-2">
                    <Lock className="h-4 w-4 text-primary" />
                    Password
                  </Label>
                  <Input
                    id="signin-password"
                    type="password"
                    placeholder="Password Anda"
                    value={signInData.password}
                    onChange={(e) => setSignInData(prev => ({ ...prev, password: e.target.value }))}
                    className="border-primary/30 focus:border-primary bg-input-background"
                    required
                  />
                </div>

                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-primary to-secondary text-primary-foreground"
                    disabled={loading || !signInData.email || !signInData.password}
                  >
                    {loading ? "Memuat..." : "Masuk 💕"}
                  </Button>
                </motion.div>
              </motion.form>
            </TabsContent>

            <TabsContent value="signup" className="space-y-4">
              <motion.form
                onSubmit={handleSignUp}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Label htmlFor="signup-email" className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-primary" />
                    Email
                  </Label>
                  <Input
                    id="signup-email"
                    type="email"
                    placeholder="nama@email.com"
                    value={signUpData.email}
                    onChange={(e) => setSignUpData(prev => ({ ...prev, email: e.target.value }))}
                    className="border-primary/30 focus:border-primary bg-input-background"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signup-displayName" className="flex items-center gap-2">
                    <Crown className="h-4 w-4 text-primary" />
                    Nama Tampilan
                  </Label>
                  <Input
                    id="signup-displayName"
                    type="text"
                    placeholder="Nama cantik untuk galeri Anda"
                    value={signUpData.displayName}
                    onChange={(e) => setSignUpData(prev => ({ ...prev, displayName: e.target.value }))}
                    className="border-primary/30 focus:border-primary bg-input-background"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signup-password" className="flex items-center gap-2">
                    <Lock className="h-4 w-4 text-primary" />
                    Password
                  </Label>
                  <Input
                    id="signup-password"
                    type="password"
                    placeholder="Minimal 6 karakter"
                    value={signUpData.password}
                    onChange={(e) => setSignUpData(prev => ({ ...prev, password: e.target.value }))}
                    className="border-primary/30 focus:border-primary bg-input-background"
                    required
                  />
                </div>

                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-primary to-secondary text-primary-foreground"
                    disabled={loading || !signUpData.email || !signUpData.password || !signUpData.displayName}
                  >
                    {loading ? "Membuat Akun..." : "Daftar 🌸"}
                  </Button>
                </motion.div>
              </motion.form>
            </TabsContent>
          </Tabs>

          <motion.div
            className="mt-6 text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.6 }}
          >
            <p className="text-muted-foreground text-sm">
              Galeri yang aman dengan backup cloud & sinkronisasi real-time 🔒
            </p>
          </motion.div>
        </Card>
      </motion.div>
    </div>
  );
}