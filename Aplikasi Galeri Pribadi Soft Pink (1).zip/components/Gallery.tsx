import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MediaCard } from "./MediaCard";
import { UploadArea } from "./UploadArea";
import { ActivityHistory } from "./ActivityHistory";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Heart, Sparkles, LogOut, Crown, Camera, Video } from "lucide-react";
import { showNotification, Notification } from "./NotificationToast";
import { Toaster } from "./ui/sonner";

interface Media {
  id: string;
  src: string;
  alt: string;
  type: 'photo' | 'video';
  file?: File;
  reactions: { [emoji: string]: number };
  uploadedAt: Date;
}

interface User {
  id: string;
  displayName: string;
}

interface GalleryProps {
  user: User;
  onLogout: () => void;
}

export function Gallery({ user, onLogout }: GalleryProps) {
  const [medias, setMedias] = useState<Media[]>([]);
  const [activities, setActivities] = useState<Notification[]>([]);

  // Load some sample photos on first load
  useEffect(() => {
    const sampleMedias: Media[] = [
      {
        id: "1",
        src: "https://images.unsplash.com/photo-1519741497674-611481863552?w=400&h=400&fit=crop",
        alt: "Pink flowers",
        type: "photo",
        reactions: { "❤️": 3, "🌸": 1 },
        uploadedAt: new Date(Date.now() - 3600000)
      },
      {
        id: "2", 
        src: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=600&fit=crop",
        alt: "Pink sunset",
        type: "photo",
        reactions: { "😍": 2, "✨": 4 },
        uploadedAt: new Date(Date.now() - 7200000)
      },
      {
        id: "3",
        src: "https://images.unsplash.com/photo-1518621012118-1d2efb441b46?w=400&h=300&fit=crop",
        alt: "Pink aesthetic",
        type: "photo",
        reactions: { "🥰": 1, "💕": 2 },
        uploadedAt: new Date(Date.now() - 10800000)
      }
    ];
    setMedias(sampleMedias);
  }, []);

  const addActivity = (activity: Omit<Notification, 'id' | 'timestamp'>) => {
    const newActivity: Notification = {
      ...activity,
      id: Date.now().toString(),
      timestamp: new Date()
    };
    setActivities(prev => [newActivity, ...prev.slice(0, 49)]); // Keep last 50 activities
    showNotification(activity);
  };

  const handleFileSelect = (files: FileList) => {
    Array.from(files).forEach(file => {
      const isVideo = file.type.startsWith('video/');
      const newMedia: Media = {
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        src: URL.createObjectURL(file),
        alt: file.name,
        type: isVideo ? 'video' : 'photo',
        file,
        reactions: {},
        uploadedAt: new Date()
      };
      
      setMedias(prev => [newMedia, ...prev]);
      
      addActivity({
        type: 'upload',
        message: `${isVideo ? 'Video' : 'Foto'} "${file.name}" berhasil diupload`,
        mediaType: isVideo ? 'video' : 'photo'
      });
    });
  };

  const handleDeleteMedia = (id: string) => {
    const mediaToDelete = medias.find(m => m.id === id);
    if (mediaToDelete) {
      if (mediaToDelete.file) {
        URL.revokeObjectURL(mediaToDelete.src);
      }
      setMedias(prev => prev.filter(m => m.id !== id));
      
      addActivity({
        type: 'delete',
        message: `${mediaToDelete.type === 'video' ? 'Video' : 'Foto'} "${mediaToDelete.alt}" telah dihapus`,
        mediaType: mediaToDelete.type
      });
    }
  };

  const handleReaction = (id: string, emoji: string) => {
    setMedias(prev => prev.map(media => {
      if (media.id === id) {
        const newReactions = { ...media.reactions };
        newReactions[emoji] = (newReactions[emoji] || 0) + 1;
        
        addActivity({
          type: 'reaction',
          message: `Memberikan reaksi ${emoji} pada ${media.type === 'video' ? 'video' : 'foto'}`,
          emoji
        });
        
        return { ...media, reactions: newReactions };
      }
      return media;
    }));
  };

  const clearAllMedia = () => {
    medias.forEach(media => {
      if (media.file) {
        URL.revokeObjectURL(media.src);
      }
    });
    setMedias([]);
    
    addActivity({
      type: 'delete',
      message: 'Semua media telah dihapus dari galeri'
    });
  };

  const clearHistory = () => {
    setActivities([]);
  };

  const photoCount = medias.filter(m => m.type === 'photo').length;
  const videoCount = medias.filter(m => m.type === 'video').length;
  const totalReactions = medias.reduce((sum, media) => 
    sum + Object.values(media.reactions).reduce((a, b) => a + b, 0), 0
  );

  return (
    <div className="space-y-8">
      <Toaster position="top-right" />
      
      {/* Header with user info */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div className="flex items-center gap-4">
          <Avatar className="h-12 w-12 border-2 border-primary/20">
            <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white">
              {user.displayName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-primary">{user.displayName}</h2>
              <Crown className="h-4 w-4 text-primary" />
            </div>
            <p className="text-muted-foreground text-sm">@{user.id}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <ActivityHistory activities={activities} onClearHistory={clearHistory} />
          <Button variant="outline" onClick={onLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Keluar
          </Button>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center space-y-4"
      >
        <div className="flex items-center justify-center space-x-2">
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Heart className="h-8 w-8 text-primary fill-current" />
          </motion.div>
          <h1 className="text-primary">Album Pribadi</h1>
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Sparkles className="h-8 w-8 text-primary" />
          </motion.div>
        </div>
        
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
            <Camera className="h-3 w-3 mr-1" />
            {photoCount} Foto
          </Badge>
          <Badge variant="outline" className="bg-secondary/50 text-secondary-foreground border-secondary">
            <Video className="h-3 w-3 mr-1" />
            {videoCount} Video
          </Badge>
          <Badge variant="outline" className="bg-pink-50 text-pink-700 border-pink-200">
            <Heart className="h-3 w-3 mr-1" />
            {totalReactions} Reaksi
          </Badge>
        </div>
        
        <p className="text-muted-foreground max-w-md mx-auto">
          Koleksi kenangan indah dalam galeri pribadi dengan tema soft pink yang menenangkan 🌸
        </p>
      </motion.div>

      {/* Upload Area */}
      <UploadArea onFileSelect={handleFileSelect} />

      {/* Gallery Controls */}
      {medias.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center justify-between"
        >
          <p className="text-muted-foreground">
            {medias.length} item dalam koleksi
          </p>
          <Button 
            variant="outline" 
            onClick={clearAllMedia}
            className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
          >
            Hapus Semua
          </Button>
        </motion.div>
      )}

      {/* Media Grid - Masonry Layout */}
      {medias.length > 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="masonry-grid"
        >
          <AnimatePresence>
            {medias.map((media) => (
              <MediaCard
                key={media.id}
                id={media.id}
                src={media.src}
                alt={media.alt}
                type={media.type}
                reactions={media.reactions}
                onDelete={handleDeleteMedia}
                onReaction={handleReaction}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-16"
        >
          <motion.div
            className="rounded-full bg-secondary/50 w-24 h-24 mx-auto mb-6 flex items-center justify-center"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Heart className="h-12 w-12 text-primary/50 fill-current" />
          </motion.div>
          <h3 className="text-primary mb-2">Belum Ada Media</h3>
          <p className="text-muted-foreground">
            Upload foto atau video pertama Anda untuk memulai koleksi galeri pribadi yang indah ✨
          </p>
        </motion.div>
      )}
    </div>
  );
}