import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogTrigger } from "./ui/dialog";
import { Trash2, Heart, Play, Pause, Volume2, VolumeX } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface MediaCardProps {
  id: string;
  src: string;
  alt: string;
  type: 'photo' | 'video';
  reactions: { [emoji: string]: number };
  onDelete: (id: string) => void;
  onReaction: (id: string, emoji: string) => void;
}

const EMOJI_OPTIONS = ['❤️', '😍', '🥰', '😊', '🌸', '✨', '🌺', '💕'];

export function MediaCard({ id, src, alt, type, reactions, onDelete, onReaction }: MediaCardProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [showReactions, setShowReactions] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(id);
  };

  const handleReaction = (emoji: string) => {
    onReaction(id, emoji);
    setShowReactions(false);
  };

  const getRandomHeight = () => {
    const heights = ['200px', '250px', '300px', '180px', '220px', '280px'];
    return heights[Math.floor(Math.random() * heights.length)];
  };

  const togglePlay = (videoElement: HTMLVideoElement) => {
    if (isPlaying) {
      videoElement.pause();
    } else {
      videoElement.play();
    }
    setIsPlaying(!isPlaying);
  };

  const toggleMute = (videoElement: HTMLVideoElement) => {
    videoElement.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  return (
    <motion.div
      className="masonry-item"
      initial={{ opacity: 0, y: 20, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -20, scale: 0.9 }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -5 }}
    >
      <Card className="group relative overflow-hidden bg-card hover:shadow-xl transition-all duration-500 border-2 border-secondary hover:border-primary/50">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <div className="cursor-pointer">
              <div 
                className="overflow-hidden relative"
                style={{ height: getRandomHeight() }}
              >
                {type === 'photo' ? (
                  <ImageWithFallback
                    src={src}
                    alt={alt}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                ) : (
                  <div className="relative w-full h-full">
                    <video
                      src={src}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      muted={isMuted}
                      loop
                      ref={(video) => {
                        if (video) {
                          video.addEventListener('play', () => setIsPlaying(true));
                          video.addEventListener('pause', () => setIsPlaying(false));
                        }
                      }}
                    />
                    <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <div className="flex gap-2">
                        <Button
                          size="icon"
                          variant="secondary"
                          className="bg-black/50 hover:bg-black/70 text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            const video = e.currentTarget.closest('.relative')?.querySelector('video') as HTMLVideoElement;
                            if (video) togglePlay(video);
                          }}
                        >
                          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                        <Button
                          size="icon"
                          variant="secondary"
                          className="bg-black/50 hover:bg-black/70 text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            const video = e.currentTarget.closest('.relative')?.querySelector('video') as HTMLVideoElement;
                            if (video) toggleMute(video);
                          }}
                        >
                          {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </DialogTrigger>
          <DialogContent className="max-w-4xl w-full p-0 bg-card">
            <div className="relative">
              {type === 'photo' ? (
                <ImageWithFallback
                  src={src}
                  alt={alt}
                  className="w-full h-auto max-h-[80vh] object-contain"
                />
              ) : (
                <video
                  src={src}
                  className="w-full h-auto max-h-[80vh] object-contain"
                  controls
                  autoPlay
                />
              )}
            </div>
          </DialogContent>
        </Dialog>
        
        {/* Control buttons */}
        <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button
            variant="secondary"
            size="icon"
            className="h-8 w-8 bg-white/90 hover:bg-white backdrop-blur-sm"
            onClick={(e) => {
              e.stopPropagation();
              setShowReactions(!showReactions);
            }}
          >
            <Heart className="h-4 w-4 text-primary" />
          </Button>
          <Button
            variant="destructive"
            size="icon"
            className="h-8 w-8"
            onClick={handleDelete}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>

        {/* Reaction picker */}
        <AnimatePresence>
          {showReactions && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="absolute top-12 right-2 bg-white/95 backdrop-blur-sm rounded-lg p-2 shadow-lg border border-primary/20 z-10"
            >
              <div className="grid grid-cols-4 gap-1">
                {EMOJI_OPTIONS.map((emoji) => (
                  <motion.button
                    key={emoji}
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                    className="text-lg p-1 hover:bg-secondary/50 rounded transition-colors"
                    onClick={() => handleReaction(emoji)}
                  >
                    {emoji}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Reactions display */}
        {Object.keys(reactions).length > 0 && (
          <div className="absolute bottom-2 left-2 right-2">
            <motion.div 
              className="bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-2 shadow-sm"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
            >
              {Object.entries(reactions).map(([emoji, count]) => (
                <motion.span
                  key={emoji}
                  className="flex items-center gap-1"
                  whileHover={{ scale: 1.1 }}
                >
                  <span className="text-sm">{emoji}</span>
                  <span className="text-xs text-muted-foreground">{count}</span>
                </motion.span>
              ))}
            </motion.div>
          </div>
        )}
      </Card>
    </motion.div>
  );
}