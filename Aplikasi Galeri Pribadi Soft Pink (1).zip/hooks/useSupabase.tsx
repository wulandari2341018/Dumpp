import { useState, useEffect } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase, auth, apiCall, uploadFile } from "../utils/supabase/client";

interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  createdAt: string;
  mediaCount: number;
  totalReactions: number;
}

interface Media {
  id: string;
  userId: string;
  fileName: string;
  alt: string;
  type: 'photo' | 'video';
  url: string;
  size: number;
  mimeType: string;
  reactions: { [emoji: string]: number };
  uploadedAt: string;
}

interface Activity {
  id: string;
  userId: string;
  type: 'upload' | 'delete' | 'reaction';
  message: string;
  mediaType?: 'photo' | 'video';
  emoji?: string;
  mediaId?: string;
  timestamp: string;
}

export function useSupabase() {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [medias, setMedias] = useState<Media[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);

  // Initialize auth state
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const session = await auth.getSession();
        setSession(session);
        setUser(session?.user || null);
        
        if (session?.user) {
          await loadUserProfile();
          await loadUserMedias();
          await loadUserActivities();
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('Auth state changed:', event, session?.user?.email);
        setSession(session);
        setUser(session?.user || null);

        if (session?.user) {
          await loadUserProfile();
          await loadUserMedias();
          await loadUserActivities();
        } else {
          setProfile(null);
          setMedias([]);
          setActivities([]);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const loadUserProfile = async () => {
    try {
      const data = await apiCall('/user/profile');
      setProfile(data.profile);
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  };

  const loadUserMedias = async () => {
    try {
      const data = await apiCall('/media/list');
      setMedias(data.media);
    } catch (error) {
      console.error('Error loading user medias:', error);
    }
  };

  const loadUserActivities = async () => {
    try {
      const data = await apiCall('/activities');
      setActivities(data.activities);
    } catch (error) {
      console.error('Error loading user activities:', error);
    }
  };

  const signUp = async (email: string, password: string, displayName: string) => {
    try {
      setLoading(true);
      const data = await auth.signUp(email, password, displayName);
      return data;
    } catch (error) {
      console.error('Signup error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      setLoading(true);
      const data = await auth.signIn(email, password);
      return data;
    } catch (error) {
      console.error('Signin error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      setLoading(true);
      await auth.signOut();
    } catch (error) {
      console.error('Signout error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const uploadMedia = async (file: File, alt: string = '') => {
    try {
      const data = await uploadFile(file, alt);
      // Refresh media list
      await loadUserMedias();
      await loadUserActivities();
      return data.media;
    } catch (error) {
      console.error('Upload media error:', error);
      throw error;
    }
  };

  const deleteMedia = async (mediaId: string) => {
    try {
      await apiCall(`/media/${mediaId}`, {
        method: 'DELETE',
      });
      // Refresh media list
      await loadUserMedias();
      await loadUserActivities();
    } catch (error) {
      console.error('Delete media error:', error);
      throw error;
    }
  };

  const addReaction = async (mediaId: string, emoji: string) => {
    try {
      const data = await apiCall(`/media/${mediaId}/reaction`, {
        method: 'POST',
        body: JSON.stringify({ emoji }),
      });
      // Refresh media list
      await loadUserMedias();
      await loadUserActivities();
      return data.reactions;
    } catch (error) {
      console.error('Add reaction error:', error);
      throw error;
    }
  };

  const clearActivities = async () => {
    try {
      await apiCall('/activities', {
        method: 'DELETE',
      });
      setActivities([]);
    } catch (error) {
      console.error('Clear activities error:', error);
      throw error;
    }
  };

  return {
    user,
    session,
    profile,
    loading,
    medias,
    activities,
    signUp,
    signIn,
    signOut,
    uploadMedia,
    deleteMedia,
    addReaction,
    clearActivities,
    refreshData: async () => {
      await loadUserProfile();
      await loadUserMedias();
      await loadUserActivities();
    }
  };
}