import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// CORS setup
app.use('*', cors({
  origin: '*',
  allowHeaders: ['Content-Type', 'Authorization'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
}));

app.use('*', logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Create storage bucket on startup
const BUCKET_NAME = 'make-d92b67e2-gallery';

async function initializeBucket() {
  try {
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === BUCKET_NAME);
    
    if (!bucketExists) {
      console.log('Creating storage bucket...');
      await supabase.storage.createBucket(BUCKET_NAME, {
        public: false,
        fileSizeLimit: 50 * 1024 * 1024, // 50MB limit
        allowedMimeTypes: ['image/*', 'video/*']
      });
      console.log('Storage bucket created successfully');
    }
  } catch (error) {
    console.error('Error initializing bucket:', error);
  }
}

// Initialize bucket on startup
initializeBucket();

// Helper function to verify user
async function verifyUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) {
    return null;
  }
  
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (error || !user) {
    return null;
  }
  
  return user;
}

// Sign up new user
app.post('/make-server-d92b67e2/auth/signup', async (c) => {
  try {
    const { email, password, displayName } = await c.req.json();
    
    if (!email || !password || !displayName) {
      return c.json({ error: 'Email, password, and display name are required' }, 400);
    }
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { displayName },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });
    
    if (error) {
      console.error('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }
    
    // Create user profile in KV store
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email: data.user.email,
      displayName,
      createdAt: new Date().toISOString(),
      mediaCount: 0,
      totalReactions: 0
    });
    
    return c.json({ 
      user: data.user,
      message: 'User created successfully' 
    });
    
  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

// Get user profile
app.get('/make-server-d92b67e2/user/profile', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile) {
      return c.json({ error: 'User profile not found' }, 404);
    }
    
    return c.json({ profile });
    
  } catch (error) {
    console.error('Get profile error:', error);
    return c.json({ error: 'Internal server error while fetching profile' }, 500);
  }
});

// Upload media
app.post('/make-server-d92b67e2/media/upload', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    const alt = formData.get('alt') as string || 'Uploaded media';
    
    if (!file) {
      return c.json({ error: 'No file provided' }, 400);
    }
    
    // Check file type
    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');
    
    if (!isVideo && !isImage) {
      return c.json({ error: 'Only images and videos are allowed' }, 400);
    }
    
    // Generate unique filename
    const fileExt = file.name.split('.').pop();
    const fileName = `${user.id}/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${fileExt}`;
    
    // Upload to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from(BUCKET_NAME)
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false
      });
    
    if (uploadError) {
      console.error('Upload error:', uploadError);
      return c.json({ error: 'Failed to upload file' }, 500);
    }
    
    // Create signed URL
    const { data: urlData } = await supabase.storage
      .from(BUCKET_NAME)
      .createSignedUrl(fileName, 60 * 60 * 24 * 365); // 1 year
    
    if (!urlData?.signedUrl) {
      return c.json({ error: 'Failed to create signed URL' }, 500);
    }
    
    // Save media metadata
    const mediaId = `media:${user.id}:${Date.now()}`;
    const mediaData = {
      id: mediaId,
      userId: user.id,
      fileName,
      alt,
      type: isVideo ? 'video' : 'photo',
      url: urlData.signedUrl,
      size: file.size,
      mimeType: file.type,
      reactions: {},
      uploadedAt: new Date().toISOString()
    };
    
    await kv.set(mediaId, mediaData);
    
    // Update user stats
    const userProfile = await kv.get(`user:${user.id}`);
    if (userProfile) {
      await kv.set(`user:${user.id}`, {
        ...userProfile,
        mediaCount: (userProfile.mediaCount || 0) + 1
      });
    }
    
    // Add activity
    const activityId = `activity:${user.id}:${Date.now()}`;
    await kv.set(activityId, {
      id: activityId,
      userId: user.id,
      type: 'upload',
      message: `${isVideo ? 'Video' : 'Foto'} "${alt}" berhasil diupload`,
      mediaType: isVideo ? 'video' : 'photo',
      mediaId,
      timestamp: new Date().toISOString()
    });
    
    return c.json({ 
      media: mediaData,
      message: 'Media uploaded successfully' 
    });
    
  } catch (error) {
    console.error('Upload error:', error);
    return c.json({ error: 'Internal server error during upload' }, 500);
  }
});

// Get user media
app.get('/make-server-d92b67e2/media/list', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const mediaList = await kv.getByPrefix(`media:${user.id}:`);
    
    // Refresh signed URLs if needed
    const refreshedMedia = await Promise.all(
      mediaList.map(async (media) => {
        try {
          // Create new signed URL
          const { data: urlData } = await supabase.storage
            .from(BUCKET_NAME)
            .createSignedUrl(media.fileName, 60 * 60 * 24 * 365);
          
          if (urlData?.signedUrl) {
            const updatedMedia = { ...media, url: urlData.signedUrl };
            await kv.set(media.id, updatedMedia);
            return updatedMedia;
          }
          return media;
        } catch (error) {
          console.error('Error refreshing URL for media:', media.id, error);
          return media;
        }
      })
    );
    
    // Sort by upload date (newest first)
    refreshedMedia.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
    
    return c.json({ media: refreshedMedia });
    
  } catch (error) {
    console.error('Get media list error:', error);
    return c.json({ error: 'Internal server error while fetching media' }, 500);
  }
});

// Delete media
app.delete('/make-server-d92b67e2/media/:mediaId', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const mediaId = c.req.param('mediaId');
    const media = await kv.get(mediaId);
    
    if (!media) {
      return c.json({ error: 'Media not found' }, 404);
    }
    
    if (media.userId !== user.id) {
      return c.json({ error: 'Unauthorized to delete this media' }, 403);
    }
    
    // Delete from storage
    const { error: deleteError } = await supabase.storage
      .from(BUCKET_NAME)
      .remove([media.fileName]);
    
    if (deleteError) {
      console.error('Storage delete error:', deleteError);
    }
    
    // Delete metadata
    await kv.del(mediaId);
    
    // Update user stats
    const userProfile = await kv.get(`user:${user.id}`);
    if (userProfile && userProfile.mediaCount > 0) {
      await kv.set(`user:${user.id}`, {
        ...userProfile,
        mediaCount: userProfile.mediaCount - 1
      });
    }
    
    // Add activity
    const activityId = `activity:${user.id}:${Date.now()}`;
    await kv.set(activityId, {
      id: activityId,
      userId: user.id,
      type: 'delete',
      message: `${media.type === 'video' ? 'Video' : 'Foto'} "${media.alt}" telah dihapus`,
      mediaType: media.type,
      timestamp: new Date().toISOString()
    });
    
    return c.json({ message: 'Media deleted successfully' });
    
  } catch (error) {
    console.error('Delete media error:', error);
    return c.json({ error: 'Internal server error during deletion' }, 500);
  }
});

// Add reaction to media
app.post('/make-server-d92b67e2/media/:mediaId/reaction', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const mediaId = c.req.param('mediaId');
    const { emoji } = await c.req.json();
    
    if (!emoji) {
      return c.json({ error: 'Emoji is required' }, 400);
    }
    
    const media = await kv.get(mediaId);
    if (!media) {
      return c.json({ error: 'Media not found' }, 404);
    }
    
    // Update reactions
    const newReactions = { ...media.reactions };
    newReactions[emoji] = (newReactions[emoji] || 0) + 1;
    
    await kv.set(mediaId, {
      ...media,
      reactions: newReactions
    });
    
    // Add activity
    const activityId = `activity:${user.id}:${Date.now()}`;
    await kv.set(activityId, {
      id: activityId,
      userId: user.id,
      type: 'reaction',
      message: `Memberikan reaksi ${emoji} pada ${media.type === 'video' ? 'video' : 'foto'}`,
      emoji,
      mediaId,
      timestamp: new Date().toISOString()
    });
    
    return c.json({ 
      reactions: newReactions,
      message: 'Reaction added successfully' 
    });
    
  } catch (error) {
    console.error('Add reaction error:', error);
    return c.json({ error: 'Internal server error while adding reaction' }, 500);
  }
});

// Get user activities
app.get('/make-server-d92b67e2/activities', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const activities = await kv.getByPrefix(`activity:${user.id}:`);
    
    // Sort by timestamp (newest first)
    activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    // Return last 50 activities
    return c.json({ activities: activities.slice(0, 50) });
    
  } catch (error) {
    console.error('Get activities error:', error);
    return c.json({ error: 'Internal server error while fetching activities' }, 500);
  }
});

// Clear user activities
app.delete('/make-server-d92b67e2/activities', async (c) => {
  try {
    const user = await verifyUser(c.req);
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const activities = await kv.getByPrefix(`activity:${user.id}:`);
    const activityIds = activities.map(activity => activity.id);
    
    if (activityIds.length > 0) {
      await kv.mdel(activityIds);
    }
    
    return c.json({ message: 'Activities cleared successfully' });
    
  } catch (error) {
    console.error('Clear activities error:', error);
    return c.json({ error: 'Internal server error while clearing activities' }, 500);
  }
});

// Health check
app.get('/make-server-d92b67e2/health', (c) => {
  return c.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch);